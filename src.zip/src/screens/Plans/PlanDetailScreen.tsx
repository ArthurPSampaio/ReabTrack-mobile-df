import React, { useMemo, useState } from "react";
import { View, Text, FlatList, Alert, TouchableOpacity } from "react-native";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type { RootStackParamList } from "../../navigation/types";
import type { AtividadeDto, PlanoDto, TipoAtividade } from "../../types/dto";
import { getPlanoById, saveAtividades, updatePlano } from "../../services/api/plans";

import Card from "../../components/ui/Card";
import Input from "../../components/ui/Input";
import Button from "../../components/ui/Button";
import StatusBadge from "../../components/ui/StatusBadge";
import { typography } from "../../theme/tokens";
import { colors } from "../../theme/colors";

type Props = NativeStackScreenProps<RootStackParamList, "PlanDetail">;

const TIPOS: TipoAtividade[] = [
  "Fortalecimento",
  "Alongamento",
  "Aeróbico",
  "Equilíbrio",
  "Outro",
];

const STATUS = ["Ativo", "Concluído", "Cancelado"] as const;

export default function PlanDetailScreen({ route, navigation }: Props) {
  const { planId } = route.params;
  const qc = useQueryClient();

  // ===== Query do plano =====
  const { data: plano, isLoading, isError, refetch } = useQuery({
    queryKey: ["plano", planId],
    queryFn: () => getPlanoById(planId),
  });

  // ===== Estados do form de atividade =====
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [form, setForm] = useState<AtividadeDto>({
    nome: "",
    tipo: "Fortalecimento",
  });
  const setCampo = (k: keyof AtividadeDto, v: any) =>
    setForm((s) => ({ ...s, [k]: v }));

  // Lista de atividades derivada
  const atividades = useMemo<AtividadeDto[]>(() => plano?.atividades ?? [], [plano]);

  // ===== Mutations (sempre no topo, fora de condicionais) =====
  const saveMut = useMutation({
    mutationFn: (ativs: AtividadeDto[]) => saveAtividades(planId, ativs),
    onSuccess: async () => {
      setForm({ nome: "", tipo: "Fortalecimento" });
      setEditingIndex(null);
      await qc.invalidateQueries({ queryKey: ["plano", planId] });
      await qc.invalidateQueries({ queryKey: ["planos"] });
    },
    onError: (e: any) => {
      const msg =
        e?.response?.data?.message?.join?.("\n") ||
        e?.response?.data?.message ||
        e?.message ||
        "Falha ao salvar";
      Alert.alert("Erro", String(msg));
    },
  });

  const updateStatus = useMutation({
    mutationFn: (s: "Ativo" | "Concluído" | "Cancelado") =>
      updatePlano(planId, { status: s }),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ["plano", planId] });
    },
    onError: (e: any) => {
      const msg =
        e?.response?.data?.message?.join?.("\n") ||
        e?.response?.data?.message ||
        e?.message ||
        "Falha ao atualizar status";
      Alert.alert("Erro", String(msg));
    },
  });
  const updateStatusMutate = (s: "Ativo" | "Concluído" | "Cancelado") =>
    updateStatus.mutate(s);

  // ===== Early returns (só depois de declarar TODOS os hooks) =====
  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <Text>Carregando...</Text>
      </View>
    );
  }
  if (isError || !plano) {
    return (
      <View style={{ padding: 16 }}>
        <Text style={{ fontWeight: "700", color: colors.danger }}>
          Erro ao carregar plano
        </Text>
        <TouchableOpacity onPress={() => refetch()}>
          <Text style={{ textDecorationLine: "underline", marginTop: 8 }}>
            Tentar novamente
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  // ===== Handlers =====
  const onAdd = () => {
    if (!form.nome.trim()) {
      Alert.alert("Atenção", "Informe pelo menos o nome da atividade.");
      return;
    }
    const nova = [...atividades, form];
    saveMut.mutate(nova);
  };

  const onEditStart = (idx: number) => {
    setEditingIndex(idx);
    setForm(atividades[idx]);
  };

  const onEditConfirm = () => {
    if (editingIndex === null) return;
    if (!form.nome.trim()) {
      Alert.alert("Atenção", "Informe pelo menos o nome da atividade.");
      return;
    }
    const nova = atividades.map((a, i) => (i === editingIndex ? form : a));
    saveMut.mutate(nova);
  };

  const onRemove = (idx: number) => {
    Alert.alert("Remover atividade", "Tem certeza que deseja remover esta atividade?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Remover",
        style: "destructive",
        onPress: () => {
          const nova = atividades.filter((_, i) => i !== idx);
          saveMut.mutate(nova);
        },
      },
    ]);
  };

  // ===== Render =====
  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      {/* Header */}
      <View
        style={{
          paddingHorizontal: 16,
          paddingTop: 12,
          paddingBottom: 10,
          borderBottomWidth: 1,
          borderBottomColor: colors.line,
        }}
      >
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text>← Voltar</Text>
        </TouchableOpacity>
        <Text style={[typography.h1, { marginTop: 6 }]}>
          {plano.objetivoGeral}
        </Text>
        <Text style={{ ...typography.muted, marginTop: 2 }}>
          {plano.diagnosticoRelacionado}
        </Text>
        <View style={{ marginTop: 6 }}>
          <StatusBadge
            status={plano.status as "Ativo" | "Concluído" | "Cancelado"}
          />
        </View>

        {/* Ações de status */}
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
          {STATUS.map((s) => (
            <TouchableOpacity
              key={s}
              onPress={() => updateStatusMutate(s)}
              style={{
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderWidth: 1,
                borderColor: colors.line,
                borderRadius: 999,
                backgroundColor: "#fff",
              }}
            >
              <Text>{`Marcar como ${s}`}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Lista de atividades + form */}
      <FlatList
        data={atividades}
        keyExtractor={(_, i) => String(i)}
        contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 32 }}
        ListHeaderComponent={
          <Card style={{ gap: 10 }}>
            <Text style={[typography.h2]}>Adicionar / Editar atividade</Text>
            <Input
              placeholder="Nome *"
              value={form.nome}
              onChangeText={(t) => setCampo("nome", t)}
            />
            <Input
              placeholder="Descrição"
              value={form.descricao || ""}
              onChangeText={(t) => setCampo("descricao", t)}
            />
            <View style={{ flexDirection: "row", gap: 8 }}>
              <Input
                placeholder="Séries"
                keyboardType="numeric"
                value={form.series ? String(form.series) : ""}
                onChangeText={(t) => setCampo("series", Number(t || 0))}
                style={{ flex: 1 }}
              />
              <Input
                placeholder="Repetições"
                keyboardType="numeric"
                value={form.repeticoes ? String(form.repeticoes) : ""}
                onChangeText={(t) => setCampo("repeticoes", Number(t || 0))}
                style={{ flex: 1 }}
              />
            </View>
            <Input
              placeholder="Frequência (ex.: 3x/semana)"
              value={form.frequencia || ""}
              onChangeText={(t) => setCampo("frequencia", t)}
            />
            <Input
              placeholder="Observações"
              value={form.observacoes || ""}
              onChangeText={(t) => setCampo("observacoes", t)}
            />

            {/* Chips de tipo */}
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {TIPOS.map((t) => {
                const active = form.tipo === t;
                return (
                  <TouchableOpacity
                    key={t}
                    onPress={() => setCampo("tipo", t)}
                    style={{
                      paddingHorizontal: 12,
                      paddingVertical: 8,
                      borderWidth: 1,
                      borderColor: active ? colors.primary : colors.line,
                      borderRadius: 999,
                      backgroundColor: active ? colors.primary : "#fff",
                    }}
                  >
                    <Text style={{ color: active ? colors.white : colors.text }}>
                      {t}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {editingIndex === null ? (
              <Button
                title={saveMut.isPending ? "Adicionando..." : "Adicionar atividade"}
                onPress={onAdd}
                disabled={saveMut.isPending}
              />
            ) : (
              <View style={{ flexDirection: "row", gap: 10 }}>
                <Button
                  title={saveMut.isPending ? "Salvando..." : "Salvar edição"}
                  onPress={onEditConfirm}
                  disabled={saveMut.isPending}
                />
                <Button
                  title="Cancelar"
                  variant="outline"
                  onPress={() => {
                    setEditingIndex(null);
                    setForm({ nome: "", tipo: "Fortalecimento" });
                  }}
                />
              </View>
            )}
          </Card>
        }
        ListEmptyComponent={
          <Text style={{ textAlign: "center", color: colors.textMuted }}>
            Nenhuma atividade cadastrada.
          </Text>
        }
        renderItem={({ item, index }) => (
          <Card>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Text style={{ fontWeight: "700" }}>
                {item.nome}
                {item.tipo ? ` • ${item.tipo}` : ""}
              </Text>
              <View style={{ flexDirection: "row", gap: 8 }}>
                <Button
                  title="Editar"
                  variant="outline"
                  onPress={() => onEditStart(index)}
                />
                <Button
                  title="Remover"
                  variant="outline"
                  onPress={() => onRemove(index)}
                />
              </View>
            </View>
            {!!item.descricao && (
              <Text style={{ marginTop: 6 }}>{item.descricao}</Text>
            )}
            <Text style={{ marginTop: 4, color: colors.textMuted }}>
              {item.series ? `Séries: ${item.series}` : ""}
              {item.repeticoes ? ` • Reps: ${item.repeticoes}` : ""}
              {item.frequencia ? ` • ${item.frequencia}` : ""}
            </Text>
            {!!item.observacoes && (
              <Text style={{ marginTop: 4, color: colors.textMuted }}>
                Obs: {item.observacoes}
              </Text>
            )}
          </Card>
        )}
      />
    </View>
  );
}
