import React from "react";
import { View, Text, FlatList, RefreshControl } from "react-native";
import { useQuery } from "@tanstack/react-query";
import { listPlanosByPaciente } from "../../services/api/plans";

import type { CompositeScreenProps } from "@react-navigation/native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type {
  RootStackParamList,
  PatientDetailTabParamList,
} from "../../navigation/types";
import type { BottomTabScreenProps } from "@react-navigation/bottom-tabs";

import Card from "../../components/ui/Card";
import Button from "../../components/ui/Button";
import { typography } from "../../theme/tokens";
import { colors } from "../../theme/colors";

type Props = CompositeScreenProps<
  BottomTabScreenProps<PatientDetailTabParamList, "Plans">,
  NativeStackScreenProps<RootStackParamList>
>;

export default function PatientPlansTab({ route, navigation }: Props) {
  const { id } = route.params; // pacienteId
  const { data, isLoading, isError, refetch, isRefetching } = useQuery({
    queryKey: ["planos", id],
    queryFn: () => listPlanosByPaciente(id),
  });

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <View
        style={{
          padding: 16,
          borderBottomWidth: 1,
          borderBottomColor: colors.line,
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text style={[typography.h1]}>Planos</Text>
        <Button
          title="+ Novo"
          onPress={() => navigation.navigate("PlanCreate", { patientId: id })}
        />
      </View>

      <FlatList
        data={data || []}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 24 }}
        refreshControl={
          <RefreshControl
            refreshing={!!isRefetching || isLoading}
            onRefresh={refetch}
            tintColor={colors.primary}
          />
        }
        ListEmptyComponent={
          !isLoading ? (
            <Text style={{ textAlign: "center", color: colors.textMuted }}>
              Nenhum plano encontrado para este paciente.
            </Text>
          ) : null
        }
        renderItem={({ item }) => (
          <Card>
            <Text style={[typography.h2]}>{item.objetivoGeral}</Text>
            <Text style={{ ...typography.muted, marginBottom: 10 }}>
              {item.diagnosticoRelacionado}
            </Text>
            <Button
              title="Abrir detalhes"
              variant="outline"
              onPress={() =>
                navigation.navigate("PlanDetail", { planId: item.id })
              }
            />
          </Card>
        )}
      />
    </View>
  );
}
