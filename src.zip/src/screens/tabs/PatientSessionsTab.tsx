import React from 'react';
import { View, Text } from 'react-native';

export default function PatientSessionsTab({ route }: any) {
  const { id } = route.params;
  return (
    <View style={{ padding:16 }}>
      <Text style={{ fontWeight:'700' }}>Sessões do paciente</Text>
      <Text style={{ marginTop:6, opacity:0.8 }}>Paciente ID: {id}</Text>
    </View>
  );
}
