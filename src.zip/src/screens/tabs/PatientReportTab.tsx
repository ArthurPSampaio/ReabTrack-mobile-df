import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';

export default function PatientReportTab({ route }: any) {
  const { id } = route.params;
  return (
    <View style={{ padding:16, gap:12 }}>
      <TouchableOpacity style={{ borderWidth:1, padding:12, borderRadius:10 }}>
        <Text style={{ textAlign:'center', fontWeight:'600' }}>Gerar Relatório (IA)</Text>
      </TouchableOpacity>
      <Text style={{ opacity:0.8 }}>Paciente ID: {id}</Text>
    </View>
  );
}
