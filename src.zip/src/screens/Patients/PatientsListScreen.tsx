import React from "react";
import {
  View,
  Text,
  ActivityIndicator,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { useQuery } from "@tanstack/react-query";
import { listPacientes } from "../../services/api/patients";

import Card from "../../components/ui/Card";
import Button from "../../components/ui/Button";
import { colors } from "../../theme/colors";
import { typography } from "../../theme/tokens";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type { RootStackParamList } from "../../navigation/types";

type Props = NativeStackScreenProps<RootStackParamList, "PatientsList">;

export default function PatientsListScreen({ navigation }: Props) {
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["pacientes"],
    queryFn: listPacientes,
  });

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator />
      </View>
    );
  }
  if (isError) {
    return (
      <View style={{ padding: 16 }}>
        <Text>Erro ao carregar pacientes.</Text>
        <TouchableOpacity onPress={() => refetch()}>
          <Text style={{ textDecorationLine: "underline", marginTop: 8 }}>
            Tentar novamente
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, padding: 16, gap: 12 }}>
      <Button
        title="Novo Paciente"
        onPress={() => navigation.navigate("PatientNew")}
      />

      <FlatList
        data={data || []}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ gap: 10 }}
        renderItem={({ item }) => (
          <Card>
            <View
              style={{ flexDirection: "row", alignItems: "center", gap: 12 }}
            >
              <View
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 22,
                  backgroundColor: colors.surface,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 1,
                  borderColor: colors.line,
                }}
              >
                <MaterialCommunityIcons
                  name="account-heart-outline"
                  size={22}
                  color={colors.brown}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[typography.h2]}>{item.nome}</Text>
                <Text style={typography.muted}>{item.diagnostico}</Text>
              </View>
              <Button
                title="Abrir"
                variant="outline"
                onPress={() =>
                  navigation.navigate("PatientDetail", {
                    id: item.id,
                    nome: item.nome,
                  })
                }
                style={{ paddingHorizontal: 16, paddingVertical: 10 }}
              />
            </View>
          </Card>
        )}
      />
    </View>
  );
}
