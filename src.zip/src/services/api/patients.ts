import { api } from './http';
import type { PacienteDto, Paginated } from '../../types/dto';

export async function listPacientes(): Promise<PacienteDto[]> {
  const resp = await api.get('/pacientes');
  const payload = resp.data;
  // backend retorna { data: [...], meta: {...} }
  if (payload && Array.isArray(payload.data)) return payload.data as PacienteDto[];
  // fallback se algum ambiente devolver array direto
  if (Array.isArray(payload)) return payload as PacienteDto[];
  return [];
}

// Cria um novo paciente
export async function createPaciente(dto: Omit<PacienteDto, 'id'>): Promise<PacienteDto> {
  const { data } = await api.post('/pacientes', dto);
  return data;
}

export async function getPaciente(id: string): Promise<PacienteDto> {
  const { data } = await api.get(`/pacientes/${id}`);
  if (data?.data) return data.data as PacienteDto; // compat com payload paginado
  return data as PacienteDto;
}