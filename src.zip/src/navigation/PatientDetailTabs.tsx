import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import type { PatientDetailTabParamList } from './types';
import PatientPlansTab from '../screens/tabs/PatientPlansTab';
import PatientSessionsTab from '../screens/tabs/PatientSessionsTab';
import PatientHistoryTab from '../screens/tabs/PatientHistoryTab';
import PatientReportTab from '../screens/tabs/PatientReportTab';
import { colors } from '../theme/colors';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const Tabs = createBottomTabNavigator<PatientDetailTabParamList>();

export default function PatientDetailTabs({ route }: any) {
  const { id } = route.params;
  return (
    <Tabs.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.line, height: 60, paddingBottom: 8 },
        tabBarIcon: ({ color, size }) => {
          const map: Record<string, string> = {
            Plans: 'clipboard-text-outline',
            Sessions: 'calendar-clock',
            History: 'history',
            Report: 'file-document-edit-outline',
          };
          const name = map[route.name] || 'circle';
          return <MaterialCommunityIcons name={name as any} size={size} color={color} />;
        },
      })}
    >
      <Tabs.Screen name="Plans" component={PatientPlansTab} initialParams={{ id }} options={{ title: 'Planos' }} />
      <Tabs.Screen name="Sessions" component={PatientSessionsTab} initialParams={{ id }} options={{ title: 'Sessões' }} />
      <Tabs.Screen name="History" component={PatientHistoryTab} initialParams={{ id }} options={{ title: 'Histórico' }} />
      <Tabs.Screen name="Report" component={PatientReportTab} initialParams={{ id }} options={{ title: 'Relatório' }} />
    </Tabs.Navigator>
  );
}
